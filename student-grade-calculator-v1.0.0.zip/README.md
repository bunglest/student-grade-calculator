# Student Grade Calculator

A simple Python program that calculates and analyzes student grades for a single course.

## How to Run
```bash
python grade_calculator.py
```

